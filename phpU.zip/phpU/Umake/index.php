<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="styles.css">
        <title> Chasseur à l'ouest </title>
    </head>
    <body>
        <header>
            <h1 class="title1"> La chasse est ouverte !</h1>
        </header>
        <article class="blockmain">
            <div class="blockdiv">
                <?php 
                include "formulaire.php"; 
                if (isset($_REQUEST['animal'])){
                     
                     if($_REQUEST['animal']=='Séléctionnez'){
                    echo" Veuillez selectionner un animal ! " ;
                     }else{
                        include "dico.php";
                     }
                    
                }else{
                    echo " ";
                     }
                ?> 
                </div>
        </article>
       
    </body>
    <footer>
    </footer>
</html>