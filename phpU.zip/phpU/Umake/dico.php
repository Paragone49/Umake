<html>
    <head>
        <title>Resulstat</title>
    </head>
<?php
    $Dictionnaire=array(
        'Loup'=>$Loup = array("Loup",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.75),
                'peau'=>$peau = array("Fourrure",1,0.6),
                'carcasse'=>$carcasse = array("Carcasse",1,4),
                'loot'=>$loot = array("Coeur de loup",1,0.45),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.75),
                'peau'=>$peau = array("Fourrure",1,0.9),
                'carcasse'=>$carcasse = array("Carcasse",1,3.15),
                'loot'=>$loot = array("Coeur de Loup",1,0.45),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",4,0.75),
                'peau'=>$peau = array("Fourrure",1,1.50),
                'carcasse'=>$carcasse = array("Carcasse",1,5.25),
                'loot'=>$loot = array("Coeur de loup",1,0.45),
            ),
        ),
        'Ours'=>$Ours = array("Ours",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.75),
                'peau'=>$peau = array("Fourrure",1,3),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,1.5),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.75),
                'peau'=>$peau = array("Fourrure",1,4.50),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,1.5),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",4,0.75),
                'peau'=>$peau = array("Fourrure",1,7.50),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,1.5),
            ),
        ),
        'OursNoir'=>$oursNoir = array("OursNoir",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.75),
                'peau'=>$peau = array("Fourrure",1,1.4),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,0.6),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.75),
                'peau'=>$peau = array("Fourrure",1,2.10),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,0.6),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",4,0.75),
                'peau'=>$peau = array("Fourrure",1,3.50),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,0.6),
            ),
        ),
        'Bison'=>$Bison = array("Bison",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Boeuf Supérieur",1,0.60),
                'peau'=>$peau = array("Fourrure",1,2),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Corne",1,0.75),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Boeuf Supérieur",2,0.60),
                'peau'=>$peau = array("Fourrure",1,3),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Corne",1,0.75),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Boeuf Supérieur",4,0.60),
                'peau'=>$peau = array("Fourrure",1,5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Corne",1,0.75),
            ),
        ),
        'Alligator'=>$Alligator = array("Alligator",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.75),
                'peau'=>$peau = array("Peau",1,1.40),
                'carcasse'=>$carcasse = array("Carcasse",1,2.60),
                'loot'=>$loot = array("Dent",1,0.40),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.75),
                'peau'=>$peau = array("Peau",1,2.10),
                'carcasse'=>$carcasse = array("Carcasse",1,3.90),
                'loot'=>$loot = array("Dent",1,0.40),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",4,0.75),
                'peau'=>$peau = array("Peau",1,3.5),
                'carcasse'=>$carcasse = array("Carcasse",1,6.50),
                'loot'=>$loot = array("Dent",1,0.40),
            ),
        ),
        'Taureau'=>$Taureau = array("Taureau",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Boeuf Supérieur",1,0.60),
                'peau'=>$peau = array("Peau",1,1.4),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Corne",1,0.45),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Boeuf Supérieur",2,0.60),
                'peau'=>$peau = array("Peau",1,2.1),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Corne",1,0.45),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Boeuf Supérieur",4,0.60),
                'peau'=>$peau = array("Peau",1,3.5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Corne",1,0.45),
            ),
        ),
        'Vache'=>$Vache = array("Vache",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Boeuf Supérieur",1,0.60),
                'peau'=>$peau = array("Peau",1,1),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("pasdeloot",1,0.00),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Boeuf Supérieur",2,0.60),
                'peau'=>$peau = array("Peau",1,1.5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("pasdeloot",1,0.00),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Boeuf Supérieur",4,0.60),
                'peau'=>$peau = array("Peau",1,2.5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("pasdeloot",1,0.00),
            ),
        ),
         'Boeuf'=>$Boeuf = array("Boeuf",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Boeuf Supérieur",1,0.60),
                'peau'=>$peau = array("Peau",1,1.40),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("pasdeloot",1,0.45),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Boeuf Supérieur",2,0.60),
                'peau'=>$peau = array("Peau",1,2.5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("pasdeloot",1,0.45),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Boeuf Supérieur",4,0.60),
                'peau'=>$peau = array("Peau",1,3.5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("pasdeloot",1,0.45),
            ),
        ),
        'Wapiti'=>$Wapiti = array("Wapiti",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Venaison",1,0.60),
                'peau'=>$peau = array("Peau",1,2.6),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Bois",1,1.35),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Venaison",2,0.60),
                'peau'=>$peau = array("Peau",1,3.9),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Bois",1,1.35),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Venaison",4,0.60),
                'peau'=>$peau = array("Peau",1,6.5),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Bois",1,1.35),
            ),
        ),
        'Elan'=>$Elan = array("Elan",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Venaison",1,0.60),
                'peau'=>$peau = array("Fourrure",1,3),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Bois",1,1.75),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Venaison",2,0.60),
                'peau'=>$peau = array("Fourrure",1,4.50),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Bois",1,1.75),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Venaison",4,0.60),
                'peau'=>$peau = array("Fourrure",1,7.50),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Bois",1,1.75),
            ),
        ),
        'Sanglier'=>$Sanglier = array("Sanglier",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Porc",1,0.60),
                'peau'=>$peau = array("Peau",1,0.84),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Défenses",1,0.45),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Porc",2,0.60),
                'peau'=>$peau = array("Peau",1,1.26),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Défenses",1,0.45),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Porc",3,0.60),
                'peau'=>$peau = array("Peau",1,2.10),
                'carcasse'=>$carcasse = array("pas de cacasse !",0,0),
                'loot'=>$loot = array("Défenses",1,0.45),
            ),
        ),
        'Cerf'=>$Cerf = array("Cerf",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Venaison",1,0.60),
                'peau'=>$peau = array("Fourrure",1,30),
                'carcasse'=>$carcasse = array("Carcasse",1,4),
                'loot'=>$loot = array("Bois",1,1.05),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Venaison",2,0.60),
                'peau'=>$peau = array("Fourrure",1,1.95),
                'carcasse'=>$carcasse = array("Carcasse",1,6),
                'loot'=>$loot = array("Bois",1,1.05),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Venaison",3,0.60),
                'peau'=>$peau = array("Fourrure",1,3.25),
                'carcasse'=>$carcasse = array("Carcasse",1,10),
                'loot'=>$loot = array("Bois",1,1.05),
            ),
        ),
        'Cougar'=>$Cougar = array("Cougar",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.75),
                'peau'=>$peau = array("Fourrure",1,2),
                'carcasse'=>$carcasse = array("Carcasse",1,5.4),
                'loot'=>$loot = array("Dent",1,0.5),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.75),
                'peau'=>$peau = array("Fourrure",1,3),
                'carcasse'=>$carcasse = array("Carcasse",1,8.1),
                'loot'=>$loot = array("Dent",1,0.5),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",3,0.75),
                'peau'=>$peau = array("Fourrure",1,5),
                'carcasse'=>$carcasse = array("Carcasse",1,13.5),
                'loot'=>$loot = array("Dent",1,0.5),
            ),
        ),
        'Biche'=>$Biche = array("Biche",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Venaison",1,0.60),
                'peau'=>$peau = array("Peau",1,0.9),
                'carcasse'=>$carcasse = array("Carcasse",1,2.8),
                'loot'=>$loot = array("pas de loot",1,1.05),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Venaison",2,0.60),
                'peau'=>$peau = array("Peau",1,1.25),
                'carcasse'=>$carcasse = array("Carcasse",1,4.2),
                'loot'=>$loot = array("pas de loot",1,1.05),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Venaison",3,0.60),
                'peau'=>$peau = array("Peau",1,2.25),
                'carcasse'=>$carcasse = array("Carcasse",1,7),
                'loot'=>$loot = array("pas de loot",1,1.05),
            ),
        ),
    );
echo " Prix de chasse pour un(e) ". $_REQUEST['animal']." !<br>";
if (isset($_REQUEST['bviande'])){
    $NomViande = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['viande'][0];
    $NombreViande = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['viande'][1];
    $PrixViande = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['viande'][2];
    


    $SommeViande=$NombreViande * $PrixViande;

    echo $NomViande." : ".$NombreViande." x ".$PrixViande . " = ".$SommeViande ." $ <br>";
    
}else{
    $SommeViande = 0;
}



//

if (isset($_REQUEST['bpeau'])){
    $NomPeau = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['peau'][0];
    $NombrePeau = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['peau'][1];
    $PrixPeau = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['peau'][2];

    $SommePeau = $PrixPeau*$NombrePeau ;

    echo $NomPeau." : ".$NombrePeau." x ".$PrixPeau." = ".$SommePeau." $ <br>" ;

}else{
    $SommePeau =0 ;
}

//

if (isset($_REQUEST['bcarcasse'])){
    $NomCarcasse = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['carcasse'][0];
    $NombreCarcasse = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['carcasse'][1];
    $PrixCarcasse = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['carcasse'][2];

    $SommeCarcasse = $PrixCarcasse*$NombreCarcasse ;

    echo $NomCarcasse." : ".$NombreCarcasse." x ".$PrixCarcasse." = ".$SommeCarcasse." $ <br>" ;

}else{
    $SommeCarcasse = 0;
}

//

if (isset($_REQUEST['bloot'])){
    $Nomloot = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['loot'][0];
    $Nombreloot = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['loot'][1];
    $Prixloot = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['loot'][2];

    $Sommeloot = $Prixloot*$Nombreloot ;

    echo $Nomloot." : ".$Nombreloot." x ".$Prixloot." = ".$Sommeloot." $ <br>" ;
    
}else{
    $Sommeloot = 0 ;
}

$Somme1chasse=$SommePeau+$SommeViande+$SommeCarcasse+$Sommeloot;

echo "Total : ".$Somme1chasse." $ ";