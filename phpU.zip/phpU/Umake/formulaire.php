<!DOCTYPE HTML>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <base href="/">
        <link href="stylesform.css">
        <title>Formulaires</title>
    </head>
    <body>
        <form class="blockform" id="form1" name="form1" method="post" action="phpU/Umake/index.php">
            <fieldset class="field" id="Chasse"><b>Votre chasse :</b>
                <div>
                    <label for="animal">Animal</label>
                    <select name="animal" id="animal">
                        <option>Séléctionnez</option>
                        <optgroup label="Massifs">
                            <option id="Alligator" name="Alligator">Alligator</option>
                            <option id=Bison" name="Bison">Bison</option>
                            <option id="Boeuf" name="Boeuf">Boeuf</option>  
                            <option id="Elan" name="Elan">Elan</option>
                            <option id="Loup" name="Loup">Loup</option>
                            <option id="Ours" name="Ours">Ours</option>
                            <option id="OursNoir" name="OursNoir">OursNoir</option>
                            <option id="Taureau" name="Taureau">Taureau</option>
                            <option id="Vache" name="Vache">Vache</option>
                            <option id="Wapiti" name="Wapiti">Wapiti</option>    
                        </optgroup>
                        <optgroup label="Imposant">
                            <option id="Sanglier" name="Sanglier">Sanglier</option>
                            <option id="Cerf" name="Cerf">Cerf</option>
                            <option id="Cougar" name="Cougar">Cougar</option>
                            <option id="Biche" name="Biche">Biche</option>
                        




                        </optgroup>    
                        

                    </select>
                </div>

                <div>
                    <label class="blocklabel"><b>Qualité</b><br> </label>
                    <input class="etoile1" type="radio" value="etoile1" name="etoile"checked>Une étoile<br>
                    <input class="etoile2" type="radio" value="etoile2" name="etoile">Deux étoiles<br>
                    <input class="etoile3" type="radio" value="etoile3" name="etoile">Trois étoiles<br>
                    
                </div>
                <input type="submit" name="button" id="button" value="Envoyer"/>
            </fieldset>          
            <fieldset class="field" id="Chasse"><b> Vente au cas par cas :</b>
                
            
                <div>
                
                    <input type="checkbox" name="bviande"checked>
                    <label>Viande</label><br>
                    <input type="checkbox" name="bpeau"checked>
                    <label>Peau</label><br>
                    <input type="checkbox" name="bcarcasse"checked>
                    <label>Carcasse</label><br>
                    <input type="checkbox" name="bloot"checked>
                    <label>Loot</label><br>
                   
                    
                    
                </div>
                
            </fieldset>
        </form>
        
        <label>
    </body>
</html>
