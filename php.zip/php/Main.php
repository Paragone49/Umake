<!DOCTYPE html>
<html>
<head>
    <title> Chasseur a l'ouest </title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1> La chasse est ouverte !</h1>
    </header>
    <article>
        <div>
            <?php include "Hub.php"; ?>
        </div>
    </article>









<footer>
    test
</footer>
</body>
</html>