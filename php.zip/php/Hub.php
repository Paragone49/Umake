<?php
$Dictionnaire=array(
    $loup = array("loup",
        $etoile1= array( $viande = array("GrosGibier",1,0.75),
            $peau = array("PeauDeLoup",1,4),
            $carcasse = array("CarcasseLoup",1,5),
            $loot = array("CoeurDeLoup",1,2),
        ),
        $etoile2= array( $viande = array("GrosGibier",2,0.75),
            $peau = array("PeauDeLoup",1,5),
            $carcasse = array("CarcasseLoup",1,5),
            $loot = array("CoeurDeLoup",1,2),
        ),
        $etoile3= array( $viande = array("GrosGibier",4,0.75),
            $peau = array("PeauDeLoup",1,5),
            $carcasse = array("CarcasseLoup",1,5),
            $loot = array("CoeurDeLoup",1,2),
        ),
    ),
    $ours = array("ours",
        $etoile1= array( $viande = array("GrosGibier",1,0.75),
            $peau = array("PeauDeOurs",1,5),
            $loot = array("GriffeDeOurs",1,2),
        ),
        $etoile2= array( $viande = array("GrosGibier",2,0.75),
            $peau = array("PeauDeOurs",1,6),
            $loot = array("GriffeDeOurs",1,2),
        ),
        $etoile3= array( $viande = array("GrosGibier",4,0.75),
            $peau = array("PeauDeOurs",1,7),
            $loot = array("GriffeDeOurs",1,2),
        ),
    ),
);
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Formulaires</title></head>

<body>
<form id="form1" name="form1" method="post" action="Main.php">


    <fieldset id="Chasse"><b>Votre chasse :</b><br>
        <p>
            <label for="animal">Animal</label>
            <select name="animal" id="animal">
                <option>Séléctionnez</option>
                    <option value="chevre">chevre</option>
                    <option value="ours">ours</option>
                    <option value="13">13</option>
                    <option value="92">92</option>
                    <option value="75">75</option>
                    <option value="448">77</option>

            </select>
        </p>
        <label><b>Qualité</b><br><br> </label>
        <input type="radio" value="etoile1" name="etoile">Une étoile<br>
        <input type="radio" value="etoile2" name="etoile">Deux étoiles<br>
        <input type="radio" value="etoile3" name="etoile">Trois étoiles<br>
    </fieldset>
    <input type="submit" name="button" id="button" value="Envoyer" />
    </p>
</form>
</body>
</html>
