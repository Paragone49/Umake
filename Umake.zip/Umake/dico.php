<html>
    <head>
        <title>Resulstat</title>
    </head>
<?php
    $Dictionnaire=array(
        'loup'=>$loup = array("Loup",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.75),
                'peau'=>$peau = array("Peau de loup",1,3),
                'carcasse'=>$carcasse = array("Carcasse de loup",1,4),
                'loot'=>$loot = array("Coeur de loup",1,2),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.75),
                'peau'=>$peau = array("Peau de loup",1,4),
                'carcasse'=>$carcasse = array("Carcasse de loup",1,5),
                'loot'=>$loot = array("CoeurDeLoup",1,2),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",4,0.75),
                'peau'=>$peau = array("Peau de loup",1,5),
                'carcasse'=>$carcasse = array("Carcasse de loup",1,6),
                'loot'=>$loot = array("Coeur de loup",1,2),
            ),
        ),
        'ours'=>$ours = array("Ours",
            'etoile1'=>$etoile1= array( 
                'viande'=>$viande = array("Gros gibier",1,0.80),
                'peau'=>$peau = array("Peau d'ours",1,5),
                'carcasse'=>$carcasse = array("pasdecacasse!",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,2),
            ),
            'etoile2'=>$etoile2= array( 
                'viande'=>$viande = array("Gros gibier",2,0.80),
                'peau'=>$peau = array("Peau d'ours",1,6),
                'carcasse'=>$carcasse = array("pasdecacasse!",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,2),
            ),
            'etoile3'=>$etoile3= array( 
                'viande'=>$viande = array("Gros gibier",4,0.80),
                'peau'=>$peau = array("Peau d'ours",1,7),
                'carcasse'=>$carcasse = array("pasdecacasse!",0,0),
                'loot'=>$loot = array("Griffe d'ours",1,2),
            ),
        ),
    );

$NomViande = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['viande'][0];
$NombreViande = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['viande'][1];
$PrixViande = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['viande'][2];
echo " Vous avez butté un ". $_REQUEST['animal']." !<br>";

$SommeViande=$NombreViande * $PrixViande;

echo $NomViande." : ".$NombreViande." x ".$PrixViande . " = ".$SommeViande ." $ <br>";

//

$NomPeau = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['peau'][0];
$NombrePeau = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['peau'][1];
$PrixPeau = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['peau'][2];

$SommePeau = $PrixPeau*$NombrePeau ;

echo $NomPeau." : ".$NombrePeau." x ".$PrixPeau." = ".$SommePeau." $ <br>" ;

//

$NomCarcasse = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['carcasse'][0];
$NombreCarcasse = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['carcasse'][1];
$PrixCarcasse = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['carcasse'][2];

$SommeCarcasse = $PrixCarcasse*$NombreCarcasse ;

echo $NomCarcasse." : ".$NombreCarcasse." x ".$PrixCarcasse." = ".$SommeCarcasse." $ <br>" ;

//

$Nomloot = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['loot'][0];
$Nombreloot = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['loot'][1];
$Prixloot = $Dictionnaire[$_REQUEST['animal']][$_REQUEST['etoile']]['loot'][2];

$Sommeloot = $Prixloot*$Nombreloot ;

echo $Nomloot." : ".$Nombreloot." x ".$Prixloot." = ".$Sommeloot." $ <br>" ;











$Somme1chasse=$SommePeau+$SommeViande+$SommeCarcasse+$Sommeloot;





echo "Total : ".$Somme1chasse." $ ";